setwd("C:\\Users\\Muditha\\Desktop\\IT24102325")
getwd()
##Question 1
#Binomial Distribution
#Random Variable X has binomial distribution with n = 50 and p = 0.85
1 - pbinom(46, 50, 0.85)

##Question 2
#X: Number of customer calls received in an hour
#Poisson distribution
#Random Variable X has binomial distribution with lambda = 12
dpois(15, 12)
