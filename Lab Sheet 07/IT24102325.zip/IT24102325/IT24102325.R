setwd("C:\\Users\\Muditha\\Desktop\\IT24102325")
getwd()

# Question1
prob_train <- (25 - 10) / (40 - 0)
prob_train


# Question2
prob_update <- pexp(2, rate = 1/3)
round(prob_update, 4)   


# Question3(i)
prob_above_130 <- 1 - pnorm(130, mean = 100, sd = 15)
round(prob_above_130, 4)   

# Question3(ii)
iq_95th <- qnorm(0.95, mean = 100, sd = 15)
round(iq_95th, 2)   